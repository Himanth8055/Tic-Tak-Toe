import {Dims, Draw} from "./Constants";

export default class Board{
  constructor(grid){
    this.grid=grid||new Array(Dims**2).fill(null);
    this.winnerIndex=null;
  }
  makeMove=(square, player)=>{
    if(this.grid[square]===null){
      this.grid[square]=player;
    }
  };
  getEmptySquares=(grid=this.grid)=>{
    let squares=[];
    grid.forEach((square,i)=>{
      if (square===null){
        squares.push(i);
      }
    });
    return squares;
  };
  isEmpty=(grid=this.grid)=>{
    return this.getEmptySquares(grid).length===Dims**2;
  };
  calculateWinner=(grid=this.grid)=>{
    const lines=[
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];
    let result=null;
    lines.forEach((el,i)=>{
      if(grid[el[0]]!==null&&grid[el[0]]===grid[el[1]]&&grid[el[0]]===grid[el[2]]){
        result=grid[el[0]];
        this.winnerIndex=i;
      }
      else if(result===null&&this.getEmptySquares(grid).length===0){
        result=Draw;
        this.winnerIndex=null;
      }
    });
    return result;
  };
  Strike=()=>{
    const defaultWidth=285;
    const diagonalWidth=400;
    switch(this.winnerIndex){
      case 0:
        return `
          transform: none;
          top: 41px;
          left: 15px;
          width: ${defaultWidth}px;
        `;
      case 1:
        return `
          transform: none;
          top: 140px;
          left: 15px;
          width: ${defaultWidth}px;
        `;
      case 2:
        return `
          transform: none;
          top: 242px;
          left: 15px;
          width: ${defaultWidth}px;
        `;
      case 3:
        return `
          transform: rotate(90deg);
          top: 145px;
          left: -86px;
          width: ${defaultWidth}px;
        `;
      case 4:
        return `
          transform: rotate(90deg);
          top: 145px;
          left: 15px;
          width: ${defaultWidth}px;
        `;
      case 5:
        return `
          transform: rotate(90deg);
          top: 145px;
          left: 115px;
          width: ${defaultWidth}px;
        `;
      case 6:
        return `
          transform: rotate(45deg);
          top: 145px;
          left: -44px;
          width: ${diagonalWidth}px;
        `;
      case 7:
        return `
          transform: rotate(-45deg);
          top: 145px;
          left: -46px;
          width: ${diagonalWidth}px;
        `;
      default:
        return null;
    }
  };
  clone=()=>{
    return new Board(this.grid.concat());
  };
}